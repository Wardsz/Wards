   const location = {
          lat:position.coords.latitude,
          long:position.coords.longitude
        };
        resolve(location);
getLocation()
    .then(location => console.log(location))
    .catch(error => console.log(error));